package net.aolkzyeoer.draconagric.client.dialogue;

import net.aolkzyeoer.draconagric.network.OpenDialoguePayload;
import net.aolkzyeoer.draconagric.network.SelectDialogueChoicePayload;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.neoforged.neoforge.network.PacketDistributor;

import java.util.ArrayList;
import java.util.List;

public class DialogueScreen extends Screen {
    private final ResourceLocation dialogueId;
    private final String speaker;
    private final String text;
    private final ResourceLocation portrait;
    private final List<String> choices;
    private final List<Button> choiceButtons = new ArrayList<>();

    public DialogueScreen(OpenDialoguePayload payload) {
        super(Component.literal(payload.speaker()));
        this.dialogueId = payload.dialogueId();
        this.speaker = payload.speaker();
        this.text = payload.text();
        this.portrait = payload.portrait();
        this.choices = payload.choices();
    }

    @Override
    protected void init() {
        choiceButtons.clear();
        int panelWidth = Math.min(560, this.width - 40);
        int panelX = Math.max(20, (this.width - panelWidth) / 2 - 70);
        int panelY = this.height - 132;
        int buttonAreaY = panelY + 86;
        int buttonWidth = Math.max(110, (panelWidth - 24) / Math.max(1, Math.min(3, choices.size())));

        for (int i = 0; i < choices.size(); i++) {
            final int choiceIndex = i;
            int bx = panelX + 12 + (i % 3) * (buttonWidth + 6);
            int by = buttonAreaY + (i / 3) * 22;
            Button button = Button.builder(Component.literal(choices.get(i)), b -> {
                PacketDistributor.sendToServer(new SelectDialogueChoicePayload(dialogueId, choiceIndex));
                Minecraft.getInstance().setScreen(null);
            }).bounds(bx, by, buttonWidth, 20).build();
            choiceButtons.add(button);
            addRenderableWidget(button);
        }
    }

    @Override
    public void render(GuiGraphics graphics, int mouseX, int mouseY, float partialTick) {
        renderTransparentBackground(graphics);
        Font font = Minecraft.getInstance().font;
        int panelW = Math.min(560, this.width - 40);
        int panelH = 112;
        int panelX = Math.max(20, (this.width - panelW) / 2 - 70);
        int panelY = this.height - panelH - 20;

        graphics.fill(0, 0, this.width, this.height, 0x66040B1F);
        renderPortrait(graphics);
        renderDialoguePanel(graphics, font, panelX, panelY, panelW, panelH);

        super.render(graphics, mouseX, mouseY, partialTick);
    }

    private void renderDialoguePanel(GuiGraphics graphics, Font font, int x, int y, int width, int height) {
        graphics.fill(x - 5, y - 5, x + width + 5, y + height + 5, 0xAA6FD8FF);
        graphics.fill(x - 2, y - 2, x + width + 2, y + height + 2, 0xDDFFFFFF);
        graphics.fill(x, y, x + width, y + height, 0xEE102542);
        graphics.fill(x, y, x + width, y + 22, 0xEE2A85D8);
        graphics.fill(x + 1, y + 23, x + width - 1, y + height - 1, 0xCC07162B);
        graphics.drawString(font, Component.literal(speaker), x + 14, y + 7, 0xFFFFFF, false);
        graphics.drawString(font, Component.literal("ADVANCEMENT COMPLETE"), x + width - 126, y + 7, 0xBFEFFF, false);
        graphics.drawWordWrap(font, Component.literal(text), x + 14, y + 34, width - 28, 0xEAF8FF);
    }

    private void renderPortrait(GuiGraphics graphics) {
        int portraitW = Math.min(230, Math.max(128, this.width / 4));
        int portraitH = portraitW;
        int portraitX = this.width - portraitW - 18;
        int portraitY = this.height - portraitH - 12;
        graphics.fill(portraitX - 8, portraitY - 8, portraitX + portraitW + 8, portraitY + portraitH + 8, 0x556FD8FF);
        graphics.fill(portraitX - 4, portraitY - 4, portraitX + portraitW + 4, portraitY + portraitH + 4, 0x33102542);
        graphics.blit(portrait, portraitX, portraitY, 0.0F, 0.0F, portraitW, portraitH, portraitW, portraitH);
    }

    @Override
    public boolean isPauseScreen() {
        return false;
    }
}
